//
//  SPOTApp.swift
//  SPOT
//
//  Created by Tilak Agarwal on 3/14/21.
//

import SwiftUI

@main
struct SPOTApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
